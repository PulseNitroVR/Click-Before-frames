# Building mobile packages

This project targets Geometry Dash 2.2081 and Geode 5.11.x. The pause menu's **Buffer** button works with touch input; a keyboard is not required to open the menu.

## Requirements

- CMake 3.21 or later and Ninja.
- A Geode SDK checkout matching the version in `mod.json` and the Geode CLI on `PATH`.
- For Android: Android NDK r29, with `ANDROID_NDK_HOME` set to the NDK directory. Geode requires Android API 23 or newer.
- For iOS: macOS with Xcode and its iOS SDK installed. Windows cannot produce an iOS binary.
- Set `GEODE_SDK` to the Geode SDK checkout path before configuring.

## Android

In PowerShell, set the toolchain paths, then build either or both device architectures:

```powershell
$env:GEODE_SDK = "C:\path\to\geode-sdk"
$env:ANDROID_NDK_HOME = "C:\path\to\android-ndk"
cmake --preset android64
cmake --build --preset android64-package
cmake --preset android32
cmake --build --preset android32-package
```

The packages are written to `build/android64/pulse.input-buffer.geode` and `build/android32/pulse.input-buffer.geode`.

## iOS

On a Mac with Xcode's command-line tools installed:

```sh
export GEODE_SDK="/path/to/geode-sdk"
cmake --preset ios
cmake --build --preset ios-package
```

The package is written to `build/ios/pulse.input-buffer.geode`. Transfer the `.geode` file to the device and install it with Geode's mod installer.
